using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movimiento : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += new Vector3(0, 0, -4) * Time.deltaTime;
        
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("TOQUE DETECTADO");

        if (other.CompareTag("Destroy"))
        {
            Destroy(gameObject);
        }

    }
}
